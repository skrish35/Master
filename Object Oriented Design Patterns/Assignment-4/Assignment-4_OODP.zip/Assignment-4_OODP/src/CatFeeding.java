
public class CatFeeding extends  FeedingBehavior{
	private String fImg;
	public CatFeeding(String fImg){
		this.fImg = fImg;
	}
	
	public String getFImg(){
		return fImg;
	}
}