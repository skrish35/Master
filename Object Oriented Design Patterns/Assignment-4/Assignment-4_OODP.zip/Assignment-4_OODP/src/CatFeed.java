public class CatFeed extends FeedingBehavior {
	
	private String Img;
	public CatFeed(){
		
		Img="milk.jpg";
	}
	
	public String getImg(){
		return Img;
	}

}
