
public class ChickenFeed extends FeedingBehavior {

	private String Img;
	public ChickenFeed(){
		Img="grass.jpg";
	}
	
	public String getImg(){
		return Img;
	}
}
