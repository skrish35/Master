public class FeedingBehavior {

	public String getImg(){
		
		return "";
	}
}
