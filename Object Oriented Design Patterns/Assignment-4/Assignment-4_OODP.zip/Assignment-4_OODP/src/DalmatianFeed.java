
public class DalmatianFeed extends FeedingBehavior  {
	
	private String Img;
	public DalmatianFeed(){
		Img="meat.jpg";
	}
	
	public String getImg(){
		return Img;
	}

}
