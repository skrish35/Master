
public class SparrowFeed extends FeedingBehavior {

	private String Img;
	public SparrowFeed(){
		Img="nuts.jpg";
	}
	
	public String getImg(){
		return Img;
	}
}
