public class PoodleFeed extends FeedingBehavior {
	
	private String Img;
	public PoodleFeed(){
		
		Img="bone.jpg";
	}
	
	public String getImg(){
		return Img;
	}

}

